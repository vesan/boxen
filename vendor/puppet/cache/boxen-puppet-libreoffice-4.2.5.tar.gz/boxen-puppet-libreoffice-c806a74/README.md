[![Stories in Ready](https://badge.waffle.io/jasonamyers/puppet-libreoffice.png?label=ready&title=Ready)](https://waffle.io/jasonamyers/puppet-libreoffice)
# Libreoffice Puppet Module for Boxen

## Usage

```puppet
include libreoffice
```

## Required Puppet Modules

* boxen

